<?php $__env->startSection('headTitle', $title. ' | IMC'); ?>
<?php $__env->startSection('bodyTitle', $title); ?>

<?php $__env->startSection('body'); ?>
<h3 class="title"><?php echo e($title); ?></h3>

<section class="mt-3">
    <div class="container-fluid">
        <div class="card" id="wrapper-tabla">
            <div class="card-body">
                <table class="table mb-0" id="tabla">
                    <thead class="thead-dark">
                        <th class="text-uppercase">Email</th>
                        <th class="text-uppercase">Idioma</th>
                        <th class="text-uppercase text-center">acción</th>
                    </thead>
                    <tbody>
                        <?php if(count($news) != 0): ?>
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($n['id']); ?>">
                                    <td class=""><?php echo $n["email"]; ?></td>
                                    <td class="text-uppercase"><?php echo $n["idioma"]; ?></td>
                                    <td class="text-center">
                                        <button type="button" onclick="deleteNews(<?php echo e($n['id']); ?>, this)" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-uppercase text-center">
                                    sin datos
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>

deleteNews = function(id, t) {
    $(t).attr("disabled",true);
    let promise = new Promise(function (resolve, reject) {
        let url = `<?php echo e(url('/adm/cliente/newsletter')); ?>/${id}`;
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open( "GET", url, true );
        
        xmlHttp.onload = function() {
            resolve(xmlHttp.responseText);
        }
        xmlHttp.send( null );
    });

    promiseFunction = () => {
        promise
            .then(function(msg) {
                $("#tabla").find(`tr[data-id="${id}"]`).remove();
                if($("#tabla").find("tbody").html().trim() == "")
                    $("#tabla").find("tbody").html('<tr><td colspan="3" class="text-uppercase text-center">sin datos</td></tr>');
                
            })
    };
    promiseFunction();
};
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('elementos.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/adm/cliente/newsletter.blade.php */ ?>