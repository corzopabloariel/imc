<div class="wrapper-oferta image" id="scroll-rrhh">
    <div class="container">
        <div class="row justify-content-end">
            <div class="col-lg-6 col-md-12 col-12 position-relative extra">
                <p class="title text-uppercase"><?php echo e(trans('words.rrhh')); ?></p>
                <div class="regular slider" style="z-index: 1;" id="ofertas">
                    <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex align-items-center justify-content-center">
                            <form method="post" action="<?php echo e(url('/envio/' . $o['id'])); ?>" enctype="multipart/form-data">
                                <input type="hidden" name="id[]" value="<?php echo e($o['id']); ?>"/>
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

                                <p class="name"><?php echo e($o["data"]["nombre"]); ?> <small class="text-uppercase" style="font-weight: initial; font-size:15px"><?php if($o["provincia"] == "BA"): ?> buenos aires <?php else: ?> neuquén <?php endif; ?></small></p>
                                <p class="t"><strong><?php echo e(trans('words.work.age')); ?></strong> <?php echo e($o["data"]["rango"]); ?></p>
                                <p class="t"><strong><?php echo e(trans('words.work.year')); ?></strong> <?php echo e($o["data"]["experiencia"]); ?></p>
                                <p class="t"><strong><?php echo e(trans('words.work.orientation')); ?></strong> <?php echo e($o["data"]["orientacion"]); ?></p>
                                
                                <div class="row" style="margin-top: 1em;">
                                    <div class="col-12">
                                        <a href="<?php echo e(URL::to($idioma . '/rrhh/' .$o['id'])); ?>" class="text-uppercase btn btn-gds" href="" tabindex="0" style="cursor: pointer"><?php echo e(trans('words.work.submit')); ?></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <ul id="sliderOfertas">
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/oferta.blade.php */ ?>