<div id="carouselExampleIndicators" class="carousel slide wrapper-slider" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php for($i = 0 ; $i < count($slider) ; $i++): ?>
            <?php if($i == 0): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
            <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
            <?php endif; ?>
        <?php endfor; ?>
    </ol>
    <div class="carousel-inner">
        <?php for($i = 0 ; $i < count($slider) ; $i++): ?>
        <?php if($i == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <img class="d-block w-100" src="<?php echo e(asset($slider[$i]['image'])); ?>" >
            <div class="carousel-caption position-absolute w-100 h-100" style="top: 0; left: 0;">
                <div class="position-absolute texto">
                    <?php echo $slider[$i]['texto']; ?>

                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>

    
</div>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/home.blade.php */ ?>