<section class="wrapper-proyectos py-5">
    <div class="container">
        <div class="row py-3">
            <div class="col-12">
                <h3 class="title">Proyectos</h3>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(URL::to('proyectos/'. $v['id'])); ?>" class="col-md-4 col-12 my-3">
                    <?php
                    $imgData = json_decode($v['img']);
                    $img = null;
                    if(count($imgData) > 0)
                        $img = $imgData[0];
                    ?>
                    <div class="position-relative">
                        <i class="fas fa-plus position-absolute"></i>
                        <div class="position-absolute w-100 h-100"></div>
                        <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                    </div>
                    <p class="mb-0"><?php echo e($v["titulo"]); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/element/proyectos.blade.php */ ?>