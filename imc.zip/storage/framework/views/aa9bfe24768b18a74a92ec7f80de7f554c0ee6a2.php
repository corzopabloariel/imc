<div style="padding-top: 50px; padding-bottom: 50px" class="wrapper-nosotros container" id="scroll-nosotros">
    <h4 style="padding-bottom:25px" class="text-uppercase text-center title"><?php echo e(trans('words.menu.us')); ?></h4>
    <div class="text-justify" style="color:#595959">
        <?php echo $nosotros["texto"]; ?>

    </div>
</div>
<div style="padding: 50px 0;" class="wrapper-mercado container">
    <h4 style="padding-bottom:25px" class="text-uppercase text-center title"><?php echo e(trans('words.menu.market')); ?></h4>
    <?php echo $nosotros["mercado"]; ?>

</div>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/nosotros.blade.php */ ?>