<section class="wrapper-proyecto">
    <div class="container">
        <div class="row py-3">
            <div class="col-12">
                <p class="title"><a href="<?php echo e(route('proyectos')); ?>">Proyectos</a> | <?php echo e($proyecto["titulo"]); ?></p>
            </div>
        </div>
        <div class="row justify-content-md-center">
            <div class="col-md-7 col-12">
                <div id="carouselExampleIndicators mb-2" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <?php for($i = 0 ; $i < count($proyecto["img"]) ; $i++): ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" <?php if($i == 0): ?> class="active" <?php endif; ?>></li>
                        <?php endfor; ?>
                    </ol>
                    <div class="carousel-inner">
                        <?php for($i = 0 ; $i < count($proyecto["img"]) ; $i++): ?>
                        <div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
                            <img class="d-block w-100" src="<?php echo e(asset($proyecto['img'][$i])); ?>" >
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-md-center mt-4">
            <div class="col-md-7 col-12">
                <h3 class="title mb-4"><?php echo e($proyecto["titulo"]); ?></h3>
                <div>
                    <?php echo $proyecto["texto"]; ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/element/proyecto.blade.php */ ?>