<ul class="sidenav navbar d-none" id="mobile-demo">
    <?php
    $urlA = ["index/es","index/en","index/it"];
    if(isset($url)) {
        switch($url) {
            case "rrhh":
                $urlA = ["es/{$url}/{$oferta['id']}","en/{$url}/{$oferta['id']}","it/{$url}/{$oferta['id']}"];
                break;
            case "servicio":
                $urlA = ["es/{$url}/{$servicio['id']}","en/{$url}/{$servicio['id']}","it/{$url}/{$servicio['id']}"];
                break;
            default:
                $urlA = ["es/{$url}","en/{$url}","it/{$url}"];
                break;
        }
    }
    ?>
    <li class="img" style="background:rgba(0, 0, 0, 0.05)">
        <a href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" class="brand-logo">
            <img src="<?php echo e(asset('/')); ?><?php echo e($empresa['images']['logo']); ?>"/>
        </a>
    </li>
    <li><a href="#" data-scroll="nav"><?php echo e(trans('words.menu.home')); ?></a></li>
    <li><a href="#" data-scroll="scroll-nosotros"><?php echo e(trans('words.menu.us')); ?></a></li>
    <li><a href="#" data-scroll="scroll-servicio"><?php echo e(trans('words.menu.services')); ?></a></li>
    <li><a href="#" data-scroll="scroll-prensa"><?php echo e(trans('words.menu.press')); ?></a></li>
    <li><a href="#" data-scroll="scroll-portfolio"><?php echo e(trans('words.menu.portfolio')); ?></a></li>
    <li><a href="#" data-scroll="scroll-rrhh"><?php echo e(trans('words.menu.rrhh')); ?></a></li>
    <li><a href="#" data-scroll="scroll-cliente"><?php echo e(trans('words.menu.clients')); ?></a></li>
    <li><a href="#" data-scroll="scroll-contacto"><?php echo e(trans('words.menu.contact')); ?></a></li>
    
    <li class="idiomas position-absolute w-100" style="bottom: 60px">
        <div>
            <a <?php if($languages == "esp"): ?> class="activeIdioma" <?php endif; ?> href="<?php echo e(URL::to($urlA[0])); ?>"><?php echo e(trans('words.languages.spanish')); ?></a> | <a <?php if($languages == "ing"): ?> class="activeIdioma" <?php endif; ?> href="<?php echo e(URL::to($urlA[1])); ?>"><?php echo e(trans('words.languages.english')); ?></a> | <a <?php if($languages == "ita"): ?> class="activeIdioma" <?php endif; ?> href="<?php echo e(URL::to($urlA[2])); ?>"><?php echo e(trans('words.languages.italian')); ?></a>
        </div>
    </li>
</ul>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/elementos/navLateral.blade.php */ ?>