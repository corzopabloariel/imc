<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rrhh extends Model
{
    protected $fillable = [
        'data',
        'orden',
        'provincia'
    ];
}
