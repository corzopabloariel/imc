<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php echo $__env->make('page.elementos.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </head>
    <body>
        <?php if(session('success')): ?>
            <div class="position-fixed w-100 text-center" style="z-index:111;">
                <div class="alert alert-success" style="display: inline-block;">
                    <?php echo session('success')["mssg"]; ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="position-fixed w-100 text-center" style="z-index:111;">
                <div class="alert alert-danger" style="display: inline-block;">
                    <?php echo $errors->first('mssg'); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="modal fade" id="modal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body"></div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('page.elementos.navLateral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('page.element.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('page.element.navModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="padding: 174px 0 60px 0;" class="wrapper-servicio">
            <div class="container"> 
                <div class="row justify-content-center">
                    <div class="col-md-10 col-12">
                        <h4 class="position-relative text-uppercase text-center title">
                            <small class="position-absolute navbar volver"><a style="color: #D7BE89 !important" href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" data-scroll="scroll-servicio">« Volver</a></small>
                            <?php echo e(trans('words.menu.services')); ?>

                        </h4>
                        <div class="tipo text-center text-uppercase py-3">
                            <?php if($servicio["tipo"] == "EMP"): ?>
                                <a style="cursor: pointer" class="activeImportat" href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" data-tipo="EMP" data-scroll="scroll-servicio"><?php echo e(trans('words.services.business')); ?></a>
                                <a style="cursor: pointer" class="" href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" data-tipo="ALQ" data-scroll="scroll-servicio"><?php echo e(trans('words.services.equipment_rental')); ?></a>
                            <?php else: ?>
                                <a style="cursor: pointer" class="" href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" data-tipo="EMP" data-scroll="scroll-servicio"><?php echo e(trans('words.services.business')); ?></a>
                                <a style="cursor: pointer" class="activeImportat" href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" data-tipo="ALQ" data-scroll="scroll-servicio"><?php echo e(trans('words.services.equipment_rental')); ?></a>
                            <?php endif; ?>
                        </div>
                        
                        <div class="container">
                            <div class="row justify-content-center">
                                <?php if( $servicio["tipo"] == "EMP"): ?>
                                <div class="col-md-2 col-6">
                                    <div class="d-flex justify-content-center">
                                        <div class="icon-servicio">
                                            <img src="<?php echo e(asset($servicio['icon'])); ?>" alt="" srcset="">
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="col-md-10 col-12">
                                    
                                    <h5><?php echo $servicio["data"]["titulo"]; ?></h5>
                                    <p><?php echo $servicio["data"]["descripcion"]; ?></p>
                                    <?php if(isset($servicio["data"]["galeria"])): ?>
                                        <div class="card-columns mt-3">
                                        <?php $__currentLoopData = $servicio["data"]["galeria"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="card">
                                                <img class="card-img-top" onclick="ampliar(this);" src="<?php echo e(asset('/') . $i['image']); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'"/>
                                                <div class="d-none">
                                                    <?php echo $i["descripcion"]; ?>     
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($servicio["data"]["seccion"])): ?>
                                        <?php $__currentLoopData = $servicio["data"]["seccion"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mt-4">
                                            <h5><?php echo e($s["titulo"]); ?></h5>
                                            <div class="text-justify"><?php echo $s["descripcion"]; ?></div>
                                            <?php if(isset($s["detalle"])): ?>
                                                <ul class="row mt-1 list-1">
                                                    <?php $__currentLoopData = $s["detalle"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($e != "null" && !is_null($e)): ?>
                                                        <li class="col-md-4 col-12"><?php echo e($e); ?></li>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                            <div class="card-columns mt-3">
                                            <?php $__currentLoopData = $s["images"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="card">
                                                    <img class="card-img-top" onclick="ampliar(this);" src="<?php echo e(asset('/') . $i['image']); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'"/>
                                                    <div class="d-none">
                                                        <?php echo $i["descripcion"]; ?>     
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('page.elementos.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('adm.elementos.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
            
            $(document).ready(function() {
                $(window).scroll(function() {     
                    let scroll = $(window).scrollTop();
                    if (scroll > 0)
                        $("#nav").addClass("activeScroll");
                    else
                        $("#nav").removeClass("activeScroll");
                });
            });
            $("nav,#menuNav").find(".activeImportat").removeClass("activeImportat");
            $("nav,#menuNav").find('[data-scroll="scroll-servicio"]').addClass("activeImportat");
            $(".tipo a").click(function() {
                localStorage.setItem('scroll', $(this).data("scroll"));
                localStorage.setItem('tipoServicio', $(this).data("tipo"));
            });
            $(".navbar a,#menuNav a").click(function() {
                localStorage.setItem('scroll', $(this).data("scroll"));
                url = "<?php echo e(URL::to( 'index/' . $idioma )); ?>";
                window.location = url;
            });

            ampliar = function(t) {
                let src = $(t).attr("src");
                let descripcion = $(t).closest(".card").find("> div").html();
                let html = "";
                html += '<div class="row">';
                    html += '<div class="col-12">';
                        html += `<img src="${src}" class="w-100 img-thumbnail" />`
                    html += '</div>';
                html += '</div>';
                if(descripcion.trim() != "") {
                    html += '<div class="row mt-3">';
                        html += '<div class="col-12">';
                            html += descripcion;
                        html += '</div>';
                    html += '</div>';
                }
                $("#modal").find(".modal-body").html(html);
                $("#modal").modal("show");
            }
        </script>
    </body>
</html>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/servicio.blade.php */ ?>