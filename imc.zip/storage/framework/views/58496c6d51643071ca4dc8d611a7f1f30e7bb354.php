<nav style="z-index: 444; top: 0; left: 0; height: auto" class="w-100 position-fixed nav" id="nav">
    <div class="nav-wrapper w-100">
        <?php echo $__env->make('page.elementos.idiomas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div style="height: inherit; z-index:1" class="position-relative d-flex justify-content-end align-items-end">
            
            
            <div class="position-absolute w-100" style="top:0;left:0">
                <div class="container position-relative">
                    <a href="<?php echo e(URL::to( 'index/' . $idioma )); ?>" class="brand-logo position-absolute" style="left: -5px;top: -30px;">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($empresa['images']['logo']); ?>"/>
                    </a>
                </div>
            </div>
            <div class="navLinea w-100">
                <div class="container position-relative h-100">
                    <div class="brand-logo position-absolute" style="left: -5px;top: -30px;">
                        <canvas></canvas>
                    </div>
                    <button id="btnMenu" class="navbar-toggler position-absolute text-white" type="button" data-toggle="modal" data-target="#menuNav" style="right: 0; top: calc(50% - 15px);">
                        <i class="fas fa-bars"></i>
                    </button>
                    <ul id="nav-mobile" class="justify-content-end text-white text-uppercase navbar mb-0 h-100 position-relative pr-0">
                        <li><a class="activeImportat" href="#" data-scroll="nav"><?php echo e(trans('words.menu.home')); ?></a></li>
                        <li><a href="#" data-scroll="scroll-nosotros"><?php echo e(trans('words.menu.us')); ?></a></li>
                        <li><a href="#" data-scroll="scroll-servicio"><?php echo e(trans('words.menu.services')); ?></a></li>
                        <li><a href="#" data-scroll="scroll-prensa"><?php echo e(trans('words.menu.press')); ?></a></li>
                        <li><a href="#" data-scroll="scroll-portfolio"><?php echo e(trans('words.menu.portfolio')); ?></a></li>
                        <li><a href="#" data-scroll="scroll-rrhh"><?php echo e(trans('words.menu.rrhh')); ?></a></li>
                        <li><a href="#" data-scroll="scroll-cliente"><?php echo e(trans('words.menu.clients')); ?></a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/nav.blade.php */ ?>