<div style="padding:50px 0;" class="wrapper-servicio" id="scroll-servicio">
    <h4 class="title text-uppercase text-center mb-0"><?php echo e(trans('words.menu.services')); ?></h4>
    
    <div class="tipo text-center text-uppercase py-3">
        <a data-tipoServicio="EMP" style="cursor: pointer" class="activeImportat" onclick="mostrarServicio(this,'EMP')"><?php echo e(trans('words.services.business')); ?></a>
        <a data-tipoServicio="ALQ" style="cursor: pointer" class="" onclick="mostrarServicio(this,'ALQ')"><?php echo e(trans('words.services.equipment_rental')); ?></a>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($servicio['tipo'] == "EMP"): ?>
                    <div data-servicio data-tipo="<?php echo e($servicio['tipo']); ?>" class="col-12 col-md-6 d-flex mt-1" style="min-height: 120px">
                <?php else: ?>
                    <div data-servicio data-tipo="<?php echo e($servicio['tipo']); ?>" class="col-12 col-md-6 mt-1 d-none" style="min-height: 120px">
                <?php endif; ?>
                    <div class="d-flex justify-content-center">
                        <div class="icon-servicio">
                            <img src="<?php echo e(asset($servicio['icon'])); ?>" alt="" srcset="">
                        </div>
                    </div>
                    <div class="pl-4">
                        <p class="servicio-title"><?php echo e($servicio["data"]["titulo"]); ?></p>
                        <p><?php echo e($servicio["data"]["descripcion"]); ?></p>
                        <a style="color: #D7BE88" href="<?php echo e(URL::to($idioma . '/servicio/' . $servicio['id'])); ?>" class="btn-flat text-uppercase p-0"><?php echo e(trans('words.read')); ?> <i class="fas fa-plus-circle"></i></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/servicio.blade.php */ ?>