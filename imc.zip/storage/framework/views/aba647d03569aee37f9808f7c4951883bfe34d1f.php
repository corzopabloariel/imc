<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php echo $__env->make('page.elementos.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </head>
    <body>
        <?php if(session('success')): ?>
            <div class="position-fixed w-100 text-center" style="z-index:111;">
                <div class="alert alert-success" style="display: inline-block;">
                    <?php echo session('success')["mssg"]; ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="position-fixed w-100 text-center" style="z-index:111;">
                <div class="alert alert-danger" style="display: inline-block;">
                    <?php echo $errors->first('mssg'); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        
        <?php echo $__env->make('page.elementos.navLateral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('page.element.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('page.element.navModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div style="padding: 174px 0 60px 0;" class="wrapper-oferta">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 col-12">
                        <h4 style="padding-bottom:25px; font-size: 30px;" class="position-relative text-uppercase text-center title">
                            <small class="position-absolute volver"><a style="color: #D7BE89 !important" href="<?php echo e(URL::to( 'index/' . $idioma )); ?>">« Volver</a></small>
                            <?php echo e(trans('words.rrhh')); ?>

                        </h4>
                        <form action="<?php echo e(url('/envio/')); ?>/<?php echo e($oferta['id']); ?>" method="post" enctype="multipart/form-data">
                            <?php echo method_field('POST'); ?>
                            
                            <div class="row">
                                <div class="col-12">
                                    <p style="font-size: 25px;color: #D7BE88;font-weight: bold;"><?php echo e($oferta["data"]["nombre"]); ?> <small class="text-uppercase" style="font-weight: initial; font-size:15px"><?php if($oferta["provincia"] == "BA"): ?> buenos aires <?php else: ?> neuquén <?php endif; ?></small></p>
                                    <p style="font-size: 18px;color: #353535;"><strong style="font-weight:700"><?php echo e(trans('words.work.age')); ?></strong> <?php echo e($oferta["data"]["rango"]); ?></p>
                                    <p style="font-size: 18px;color: #353535;"><strong style="font-weight:700"><?php echo e(trans('words.work.year')); ?></strong> <?php echo e($oferta["data"]["experiencia"]); ?></p>
                                    <p style="font-size: 18px;color: #353535;"><strong style="font-weight:700"><?php echo e(trans('words.work.orientation')); ?></strong> <?php echo e($oferta["data"]["orientacion"]); ?></p>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-12"><input class="form-control input" type="text" name="nombre" placeholder="<?php echo e(trans('words.work.form.name')); ?>"/></div>
                                <div class="col-md-6 col-12"><input class="form-control input" type="text" name="apellido" placeholder="<?php echo e(trans('words.work.form.last_name')); ?>"/></div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12"><input class="form-control input" type="email" name="email" placeholder="Email"/></div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-6 col-12"><input class="form-control input" type="text" name="formacion" placeholder="<?php echo e(trans('words.work.form.formation')); ?>"/></div>
                                <div class="col-md-6 col-12 texto2">
                                    <label><?php echo e(trans('words.work.form.file')); ?><input accept="application/pdf,image/jpeg,image/png" type="file" name="archivo"/></label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12 d-flex justify-content-center">
                                    <button type="submit" class="btn-gds btn text-uppercase"><?php echo e(trans('words.work.form.submit')); ?></button>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('page.elementos.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('adm.elementos.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <script>
            
            $(document).ready(function() {
                $(window).scroll(function() {     
                    let scroll = $(window).scrollTop();
                    if (scroll > 0)
                        $("#nav").addClass("activeScroll");
                    else
                        $("#nav").removeClass("activeScroll");
                });
            });
            $("nav").find(".activeImportat").removeClass("activeImportat");
            $("nav").find('[data-scroll="scroll-rrhh"]').addClass("activeImportat");

            $(".navbar a").click(function(e) {
                e.preventDefault();
                let url = "<?php echo e(URL::to( 'index/' . $idioma )); ?>";
                localStorage.setItem('scroll', $(this).data("scroll"));

                window.location = url;
                return false;
            });
        </script>
    </body>
</html>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/rrhh.blade.php */ ?>