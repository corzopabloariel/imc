<div style="padding-top: 50px; padding-bottom: 50px" class="wrapper-clientes" id="scroll-cliente">
    <h4 class="title text-uppercase text-center"><?php echo e(trans('words.menu.clients')); ?></h4>
    <div class="container position-relative">
        <div class="row justify-content-center">
            <div class="col-11">
                
                <div class="regular slider" id="clientes">
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="d-flex align-items-center justify-content-center">
                            <img src="<?php echo e(asset('/')); ?><?php echo e($c); ?>">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/clientes.blade.php */ ?>