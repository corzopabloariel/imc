<?php $__env->startSection('headTitle', $title . " | IMC"); ?>
<?php $__env->startSection('bodyTitle', $title); ?>

<?php $__env->startSection('body'); ?>

<h3 class="title"><?php echo e($title); ?></h3>

<section>
    <div class="container-fluid">
        <div class="card mt-3">
            <div class="card-body">
                <form novalidate method="POST" action="<?php echo e(url('/adm/contenido/' . strtolower($seccion) . '/update')); ?>"  enctype="multipart/form-data">
                    <?php echo method_field("POST"); ?>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <?php echo $__env->make('adm.contenido.' . $seccion, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('elementos.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/adm/contenido/edit.blade.php */ ?>