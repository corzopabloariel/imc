<div style="padding: 50px 0;" class="wrapper-portfolio" id="scroll-portfolio">
    <div class="container">
        <h4 class="title text-uppercase text-center"><?php echo e(trans('words.menu.portfolio')); ?></h4>
        <p style="padding-top: 1em;" id="familias" class="text-center text-uppercase">
            <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a onclick='portfolioFamilia(this)' class='' style='cursor:pointer' data-familia data-id='<?php echo e($k); ?>'><?php echo e($v); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
        <div class="row">
        <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-trabajo data-familia_id="<?php echo e($trabajo['familia_id']); ?>" class="col-md-4 col-12">
                <div class="position-relative">
                    <p class="position-absolute"><?php echo e($trabajo["nombre"]); ?></p>
                    <div onclick="trabajo(<?php echo e($trabajo['id']); ?>)" class="position-absolute d-flex w-100 h-100 align-items-center justify-content-center" style="background-color: rgba(0,0,0,0.4);">
                        <div class="d-flex flex-column align-items-center">
                            <p style="color: #D1BF7F;font-size: 30px; margin-bottom: 1em;font-weight: bold;text-transform: uppercase;text-shadow: 0 0 10px #000000;"><?php echo e($trabajo["nombre"]); ?></p>
                            <p class="text-center plus d-flex align-items-center justify-content-center"><i class="fas fa-plus"></i></p>
                        </div>
                    </div>
                    <?php if(isset($trabajo['imagenes'][0])): ?>
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" style="cursor: pointer; display: block;" src="<?php echo e(asset('/')); ?><?php echo e($trabajo['imagenes'][0]['image']); ?>" class="w-100" alt="" />
                    <?php else: ?>
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" style="cursor: pointer; display: block;" src="<?php echo e(asset('/')); ?>" class="w-100" alt="" />
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /* C:\Users\Pablo\Desktop\imc - new\resources\views/page/element/portfolio.blade.php */ ?>