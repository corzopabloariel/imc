<nav class="navbar navbar-expand-lg navbar-light p-0">
    <div class="container">
        <a class="navbar-brand m-0 p-0" href="<?php echo e(URL::to( '/' )); ?>">
            <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($empresa['img']['logo'])); ?>?t=<?php echo time(); ?>" />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end align-items-end flex-column" id="navbarSupportedContent">
            <div class="submenu">
                <ul class="p-0">
                    <li><a href="<?php echo e(URL::to( 'presupuesto' )); ?>" class="nav-link text-uppercase p-0">solicitar presupuesto</a></li>
                    <li><i class="fas fa-paper-plane mr-2" style="color: #FF7102"></i><a href="mailto:<?php echo e($empresa['email'][0]['e']); ?>"><?php echo e($empresa["email"][0]["e"]); ?></a></li>
                </ul>
            </div>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('empresa')); ?>">Empresa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('productos')); ?>">Productos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('ecobruma')); ?>">Ecobruma</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('videos')); ?>">Videos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('clientes')); ?>">Clientes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('proyectos')); ?>">Proyectos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contacto')); ?>">Contacto</a>
                </li>
                <li class="nav-item">
                    <i class="fas fa-search buscar"></i>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /* C:\Users\Pablo\Desktop\gds\resources\views/page/menu.blade.php */ ?>